Linee guida per eseguire le simulazioni.
Per poter eseguire le simulazioni è necessario lanciare lo script run.py presente in ogni cartella.
Lanciata una simulazione verranno visualizzati tutti gli step fino ad arrivare al termine della stessa.
Terminata la simulazione bisogna attendere che l'esecuzione dello script sia terminato.
Per generare i risultati finali bisogna eseguire lo script generatecsv.py
Per modificare la capacità dei parcheggi in percentuale bisogna aprire lo script setcapacity.py presente nella cartella Python-scripts e modificare il parametro in percentuale come preferisce l'utente.
I risultati della simulazione saranno presenti nella cartella Outputs, quelli già presenti riguardano per il caso 100% di capienza il tempo di parcheggio, mentre per gli altri casi riguardano la distanza percorsa in metri.



NB è necessario modificare il percorso dei file in ogni script 